import { createContext, useContext, useState, useEffect } from 'react';
import { courses as initialCourses } from '../data/courses';

const CourseContext = createContext();

export const useCourse = () => useContext(CourseContext);

export const CourseProvider = ({ children }) => {
    const [courses, setCourses] = useState(initialCourses);
    const [loading, setLoading] = useState(true);

    // Load progress from localStorage on mount
    useEffect(() => {
        const savedProgress = localStorage.getItem('courseProgress');
        if (savedProgress) {
            // Merge saved progress with initial structure (to keep content updates)
            const parsedProgress = JSON.parse(savedProgress);
            // Simplify: Just using saved state for now, assuming structure hasn't changed drastically
            // In a real app we'd merge carefully using IDs
            setCourses(parsedProgress);
        }
        setLoading(false);
    }, []);

    // Save changes to localStorage
    useEffect(() => {
        if (!loading) {
            localStorage.setItem('courseProgress', JSON.stringify(courses));
        }
    }, [courses, loading]);

    const markLessonComplete = (courseId, lessonId, score = null) => {
        setCourses(prevCourses => {
            return prevCourses.map(course => {
                if (course.id !== courseId) return course;

                return {
                    ...course,
                    lessons: course.lessons.map(lesson => {
                        if (lesson.id !== lessonId) return lesson;
                        return {
                            ...lesson,
                            completed: true,
                            score: score !== null ? score : lesson.score
                        };
                    })
                };
            });
        });
    };

    const getCourseProgress = (courseId) => {
        const course = courses.find(c => c.id === courseId);
        if (!course) return 0;
        const completed = course.lessons.filter(l => l.completed).length;
        return Math.round((completed / course.lessons.length) * 100);
    };

    const getTotalCompletedLessons = () => {
        return courses.reduce((total, course) => {
            return total + course.lessons.filter(l => l.completed).length;
        }, 0);
    };

    return (
        <CourseContext.Provider value={{ courses, markLessonComplete, getCourseProgress, getTotalCompletedLessons }}>
            {!loading && children}
        </CourseContext.Provider>
    );
};
