import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useCourse } from '../context/CourseContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { PlayCircle, Clock, BarChart } from 'lucide-react';

const Dashboard = () => {
    const { user, logout } = useAuth();
    const { courses, getCourseProgress, getTotalCompletedLessons } = useCourse();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const startCourse = (courseId, firstLessonId) => {
        navigate(`/course/${courseId}/lesson/${firstLessonId}`);
    };

    const totalLessons = getTotalCompletedLessons();

    return (
        <div className="p-8 max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
                    <p className="text-gray-600">Welcome back, {user?.name}</p>
                </div>
                <Button variant="outline" onClick={handleLogout} className="w-auto py-2 px-4 shadow-none">Logout</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="font-semibold text-gray-500 mb-2">My Courses</h3>
                    <p className="text-4xl font-bold text-primary">{courses.length}</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="font-semibold text-gray-500 mb-2">Lessons Completed</h3>
                    <p className="text-4xl font-bold text-green-600">{totalLessons}</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="font-semibold text-gray-500 mb-2">Certificates</h3>
                    <p className="text-4xl font-bold text-purple-600">0</p>
                </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Courses</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {courses.map(course => {
                    const progress = getCourseProgress(course.id);
                    return (
                        <div key={course.id} className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
                            <div className="h-48 overflow-hidden relative">
                                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                                <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-200">
                                    <div className="h-full bg-green-500 transition-all duration-500" style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                            <div className="p-6 flex flex-col flex-grow">
                                <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{course.description}</p>

                                <div className="flex items-center gap-4 text-sm text-gray-500 mb-6 mt-auto">
                                    <div className="flex items-center gap-1">
                                        <PlayCircle size={16} />
                                        <span>{course.lessons.length} Lessons</span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                        <BarChart size={16} />
                                        <span>{progress}% Complete</span>
                                    </div>
                                </div>

                                <Button onClick={() => startCourse(course.id, course.lessons[0].id)}>
                                    {progress > 0 ? 'Continue Learning' : 'Start Course'}
                                </Button>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Dashboard;
