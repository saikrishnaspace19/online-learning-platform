import React, { useState } from 'react';
import { Button } from '../ui/Button';
import { CheckCircle, XCircle, Award } from 'lucide-react';

const QuizEngine = ({ questions, onComplete }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [showFeedback, setShowFeedback] = useState(false);
    const [score, setScore] = useState(0);
    const [quizCompleted, setQuizCompleted] = useState(false);

    const currentQuestion = questions[currentIndex];

    const handleOptionSelect = (optionIndex) => {
        if (showFeedback) return;
        setSelectedOption(optionIndex);
    };

    const handleSubmit = () => {
        if (selectedOption === null) return;

        const isCorrect = selectedOption === currentQuestion.correctAnswer;
        if (isCorrect) {
            setScore(score + 1);
        }
        setShowFeedback(true);
    };

    const handleNext = () => {
        if (currentIndex < questions.length - 1) {
            setCurrentIndex(currentIndex + 1);
            setSelectedOption(null);
            setShowFeedback(false);
        } else {
            setQuizCompleted(true);
            if (onComplete) onComplete(score + (selectedOption === currentQuestion.correctAnswer ? 0 : 0)); // Score already updated
        }
    };

    if (quizCompleted) {
        const percentage = Math.round((score / questions.length) * 100);
        return (
            <div className="bg-white p-8 rounded-2xl shadow-lg text-center animate-fade-in-up">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-100 text-yellow-600 mb-6">
                    <Award size={40} />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Quiz Completed!</h2>
                <p className="text-gray-600 mb-6">You scored {score} out of {questions.length}</p>

                <div className="text-5xl font-bold text-primary mb-8">{percentage}%</div>

                <Button onClick={() => window.location.reload()} variant="outline">Retry Quiz</Button>
            </div>
        );
    }

    return (
        <div className="bg-white p-6 rounded-2xl shadow-lg max-w-2xl mx-auto">
            <div className="mb-6 flex justify-between items-center text-sm text-gray-500">
                <span>Question {currentIndex + 1} of {questions.length}</span>
                <span>Score: {score}</span>
            </div>

            <h3 className="text-xl font-bold text-gray-900 mb-6">{currentQuestion.question}</h3>

            <div className="space-y-3 mb-8">
                {currentQuestion.options.map((option, index) => {
                    let styleClass = "border-gray-200 hover:bg-gray-50";
                    if (showFeedback) {
                        if (index === currentQuestion.correctAnswer) {
                            styleClass = "bg-green-50 border-green-500 text-green-700";
                        } else if (index === selectedOption) {
                            styleClass = "bg-red-50 border-red-500 text-red-700";
                        }
                    } else if (selectedOption === index) {
                        styleClass = "border-primary bg-indigo-50 text-primary ring-1 ring-primary";
                    }

                    return (
                        <button
                            key={index}
                            onClick={() => handleOptionSelect(index)}
                            className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 flex justify-between items-center ${styleClass}`}
                            disabled={showFeedback}
                        >
                            <span>{option}</span>
                            {showFeedback && index === currentQuestion.correctAnswer && <CheckCircle size={20} className="text-green-500" />}
                            {showFeedback && index === selectedOption && index !== currentQuestion.correctAnswer && <XCircle size={20} className="text-red-500" />}
                        </button>
                    );
                })}
            </div>

            <div className="flex justify-end">
                {!showFeedback ? (
                    <Button onClick={handleSubmit} disabled={selectedOption === null} className="w-auto">
                        Submit Answer
                    </Button>
                ) : (
                    <Button onClick={handleNext} className="w-auto">
                        {currentIndex < questions.length - 1 ? 'Next Question' : 'See Results'}
                    </Button>
                )}
            </div>
        </div>
    );
};

export default QuizEngine;
