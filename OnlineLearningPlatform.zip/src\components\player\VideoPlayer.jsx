import React from 'react';

const VideoPlayer = ({ src, poster, title }) => {
    return (
        <div className="relative w-full rounded-2xl overflow-hidden shadow-2xl bg-black aspect-video group">
            <video
                className="w-full h-full object-cover"
                controls
                src={src}
                poster={poster}
            >
                Your browser does not support the video tag.
            </video>
            <div className="absolute top-0 left-0 w-full p-4 bg-gradient-to-b from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                <h3 className="text-white font-medium text-lg text-shadow">{title}</h3>
            </div>
        </div>
    );
};

export default VideoPlayer;
