import React, { useState, useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import VideoPlayer from '../components/player/VideoPlayer';
import QuizEngine from '../components/quiz/QuizEngine';
import { useCourse } from '../context/CourseContext';
import { PlayCircle, CheckCircle, Circle, HelpCircle } from 'lucide-react';
import { Button } from '../components/ui/Button';

const LessonPage = () => {
    const { courseId, lessonId } = useParams();
    const { courses, markLessonComplete } = useCourse();

    // Find course and lesson from Context
    const course = courses.find(c => c.id === courseId);
    const currentLesson = course?.lessons.find(l => l.id === lessonId);

    // State for active lesson (default to URL param)
    const [activeLesson, setActiveLesson] = useState(currentLesson || null);

    // Update active lesson if URL param changes or courses data updates
    useEffect(() => {
        if (course && lessonId) {
            const lesson = course.lessons.find(l => l.id === lessonId);
            setActiveLesson(lesson);
        }
    }, [courseId, lessonId, courses]); // depend on courses to get updated completion status

    if (!course) return <Navigate to="/dashboard" />;
    if (!activeLesson) return <div>Lesson not found</div>;

    const handleLessonComplete = () => {
        markLessonComplete(courseId, activeLesson.id);
    };

    const handleQuizComplete = (score) => {
        markLessonComplete(courseId, activeLesson.id, score);
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <div className="bg-white shadow-sm border-b border-gray-200 px-8 py-4">
                <h1 className="text-xl font-bold text-gray-900">{course.title}</h1>
            </div>

            <div className="flex flex-1 flex-col lg:flex-row max-w-8xl mx-auto w-full">
                {/* Main Content - Video or Quiz */}
                <div className="flex-1 p-6 lg:p-8 overflow-y-auto">
                    <div className="max-w-4xl mx-auto">
                        {activeLesson.type === 'quiz' ? (
                            <QuizEngine
                                questions={activeLesson.questions}
                                onComplete={handleQuizComplete}
                            />
                        ) : (
                            <>
                                <VideoPlayer
                                    src={activeLesson.videoUrl}
                                    title={activeLesson.title}
                                    poster={course.thumbnail}
                                />

                                <div className="mt-6">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h2 className="text-2xl font-bold text-gray-900">{activeLesson.title}</h2>
                                            <p className="text-gray-600 mt-2">{course.description}</p>
                                        </div>
                                        {activeLesson.completed && (
                                            <div className="badge bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">Completed</div>
                                        )}
                                    </div>

                                    <div className="mt-6 flex gap-4">
                                        {!activeLesson.completed && (
                                            <Button className="w-auto" onClick={handleLessonComplete}>Mark as Complete</Button>
                                        )}
                                        {/* Logic to find next lesson could be added here */}
                                        <Button variant="outline" className="w-auto">Next Lesson</Button>
                                    </div>
                                </div>
                            </>
                        )}

                    </div>
                </div>

                {/* Sidebar - Lesson List */}
                <div className="w-full lg:w-96 bg-white border-l border-gray-200 overflow-y-auto h-[calc(100vh-64px)]">
                    <div className="p-6">
                        <h3 className="font-bold text-gray-900 mb-4">Course Content</h3>
                        <div className="space-y-2">
                            {course.lessons.map((lesson) => (
                                <button
                                    key={lesson.id}
                                    onClick={() => setActiveLesson(lesson)} // Navigation logic should ideally change URL too, but simple state switch is okay for now if we sync
                                    className={`w-full flex items-center p-3 rounded-lg text-left transition-colors ${activeLesson.id === lesson.id
                                            ? 'bg-secondary text-primary'
                                            : 'hover:bg-gray-50 text-gray-700'
                                        }`}
                                >
                                    <div className="mr-3">
                                        {lesson.completed ? (
                                            <CheckCircle size={20} className="text-green-500" />
                                        ) : (lesson.type === 'quiz') ? (
                                            <HelpCircle size={20} className="text-orange-400" />
                                        ) : activeLesson.id === lesson.id ? (
                                            <PlayCircle size={20} />
                                        ) : (
                                            <Circle size={20} className="text-gray-300" />
                                        )}
                                    </div>
                                    <div>
                                        <div className="font-medium text-sm">{lesson.title}</div>
                                        <div className="text-xs opacity-70">{lesson.duration}</div>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LessonPage;
