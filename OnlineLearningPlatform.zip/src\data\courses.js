export const courses = [
    {
        id: '1',
        title: 'Introduction to Web Development',
        description: 'Learn the basics of HTML, CSS, and JavaScript.',
        thumbnail: 'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?ixlib=rb-4.0.3&auto=format&fit=crop&w=1770&q=80',
        lessons: [
            {
                id: '101',
                title: 'Welcome to the Course',
                duration: '2:30',
                videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                completed: true
            },
            {
                id: '102',
                title: 'HTML Basics',
                duration: '15:45',
                videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
                completed: false
            },
            {
                id: '103',
                title: 'CSS Styling Quiz',  // This is a quiz lesson
                duration: '5:00',
                type: 'quiz',
                questions: [
                    {
                        question: "What does CSS stand for?",
                        options: ["Creative Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Colorful Style Sheets"],
                        correctAnswer: 1
                    },
                    {
                        question: "Which HTML tag is used to define an internal style sheet?",
                        options: ["<css>", "<script>", "<style>", "<link>"],
                        correctAnswer: 2
                    },
                    {
                        question: "Which property is used to change the background color?",
                        options: ["color", "bgcolor", "background-color", "bg-color"],
                        correctAnswer: 2
                    }
                ],
                completed: false
            }
        ]
    },
    {
        id: '2',
        title: 'Advanced React Patterns',
        description: 'Master higher-order components and hooks.',
        thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=1770&q=80',
        lessons: [
            {
                id: '201',
                title: 'Custom Hooks',
                duration: '10:00',
                videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
                completed: false
            }
        ]
    }
];
