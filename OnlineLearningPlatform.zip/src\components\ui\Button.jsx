import React from 'react';

export const Button = ({ children, variant = 'primary', className = '', ...props }) => {
    const baseStyles = "w-full py-3 px-4 rounded-xl font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2";
    const variants = {
        primary: "bg-primary text-white hover:bg-indigo-700 shadow-lg shadow-indigo-500/30",
        secondary: "bg-secondary text-primary hover:bg-indigo-200",
        outline: "border-2 border-gray-200 text-gray-600 hover:border-primary hover:text-primary"
    };

    return (
        <button className={`${baseStyles} ${variants[variant]} ${className}`} {...props}>
            {children}
        </button>
    );
};
